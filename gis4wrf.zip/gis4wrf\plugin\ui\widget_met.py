# GIS4WRF (https://doi.org/10.5281/zenodo.1288569)
# Copyright (c) 2018 D. Meyer and M. Riechert. Licensed under MIT.


from PyQt5.QtCore import Qt, QDate, QTime, QDateTime, pyqtSignal
from PyQt5.QtGui import QDoubleValidator
from PyQt5.QtWidgets import (
    QWidget, QPushButton, QVBoxLayout, QGridLayout, QGroupBox, QLabel, QHBoxLayout, 
    QComboBox, QRadioButton, QTreeWidget, QTreeWidgetItem, QDateTimeEdit, QTreeWidgetItemIterator,
    QListWidget, QListWidgetItem, QProgressBar, QMessageBox, QLineEdit, QSpinBox
)


from gis4wrf.core.downloaders.datasets import met_datasets
from gis4wrf.core.downloaders.met import (
    get_met_products, is_met_dataset_downloaded, get_met_dataset_path, download_met_dataset)
from gis4wrf.core.crs import CRS
from gis4wrf.core import UserError 
from gis4wrf.core import logger
    
from gis4wrf.plugin.options import get_options
from gis4wrf.plugin.geo import rect_to_bbox
from gis4wrf.plugin.broadcast import Broadcast
from gis4wrf.plugin.ui.helpers import add_grid_lineedit, MessageBar, reraise
from gis4wrf.plugin.ui.thread import TaskThread


DECIMALS = 50
LON_VALIDATOR = QDoubleValidator(-180.0, 180.0, DECIMALS)
LAT_VALIDATOR = QDoubleValidator(-90.0, 90.0, DECIMALS)
# higher resolution than default (100)
PROGRESS_BAR_MAX = 1000

# TODO display bbox as vector layer if not global extent

class MetToolsDownloadManager(QWidget):
    tab_active = pyqtSignal()
    go_to_data_tab = pyqtSignal()

    def __init__(self, iface) -> None:
        super().__init__()

        self.iface = iface
        self.options = get_options()
        self.msg_bar = MessageBar(iface)
        self.project = None

        vbox = QVBoxLayout()
        self.setLayout(vbox)
       
        hbox = QHBoxLayout()
        vbox.addLayout(hbox)

        hbox.addWidget(QLabel('Dataset: '))
        self.cbox_dataset = QComboBox()
        self.cbox_dataset.addItem('-')
        for index, (dataset_name, dataset_label) in enumerate(met_datasets.items()):
            self.cbox_dataset.addItem(dataset_name, dataset_name)
            self.cbox_dataset.setItemData(index + 1, dataset_label, Qt.ToolTipRole)
        self.cbox_dataset.currentIndexChanged.connect(self.on_dataset_changed)
        hbox.addWidget(self.cbox_dataset)
        
        hbox_product_name = QHBoxLayout()
        vbox.addLayout(hbox_product_name)
        hbox_product_name.addWidget(QLabel('Product: '))
        self.cbox_product = QComboBox()
        self.cbox_product.currentIndexChanged.connect(self.on_product_changed)
        hbox_product_name.addWidget(self.cbox_product)

        hbox_start_datetime = QHBoxLayout()
        vbox.addLayout(hbox_start_datetime)
        self.dedit_start_date = QDateTimeEdit()
        self.dedit_start_date.setCalendarPopup(True)
        hbox_start_datetime.addWidget(QLabel('Start: '))
        hbox_start_datetime.addWidget(self.dedit_start_date)

        hbox_end_datetime = QHBoxLayout()
        vbox.addLayout(hbox_end_datetime)
        self.dedit_end_date = QDateTimeEdit()
        self.dedit_end_date.setCalendarPopup(True)
        hbox_end_datetime.addWidget(QLabel('End: '))
        hbox_end_datetime.addWidget(self.dedit_end_date)

        hbox_interval = QHBoxLayout()
        vbox.addLayout(hbox_interval)
        self.spin_interval = QSpinBox()
        self.spin_interval.setRange(1, 24)
        self.spin_interval.setValue(3)
        hbox_interval.addWidget(QLabel('Interval (hours): '))
        hbox_interval.addWidget(self.spin_interval)

        gbox_extent = QGroupBox('Extent')
        vbox.addWidget(gbox_extent)
        vbox_extent = QVBoxLayout()
        gbox_extent.setLayout(vbox_extent)

        hbox_extent = QHBoxLayout()
        vbox_extent.addLayout(hbox_extent)
        self.radio_global = QRadioButton('Global')
        self.radio_global.toggled.connect(self.on_extent_radio_button_clicked)
        hbox_extent.addWidget(self.radio_global)
        self.radio_subset = QRadioButton('Subset')
        self.radio_subset.toggled.connect(self.on_extent_radio_button_clicked)
        hbox_extent.addWidget(self.radio_subset)

        self.widget_extent = QWidget()
        vbox_extent.addWidget(self.widget_extent)
        grid_extent = QGridLayout()
        self.widget_extent.setLayout(grid_extent)
        self.widget_extent.hide()
        self.top = add_grid_lineedit(grid_extent, 0, 'North Latitude',
                                     LAT_VALIDATOR, '°', required=True)
        self.right = add_grid_lineedit(grid_extent, 1, 'East Longitude',
                                      LON_VALIDATOR, '°', required=True)
        self.left = add_grid_lineedit(grid_extent, 2, 'West Longitude',
                                       LON_VALIDATOR, '°', required=True)
        self.bottom = add_grid_lineedit(grid_extent, 3, 'South Latitude',
                                        LAT_VALIDATOR, '°', required=True)
        self.extent_from_active_layer = QPushButton('Set from Active Layer')
        grid_extent.addWidget(self.extent_from_active_layer, 4, 1)
        self.extent_from_active_layer.clicked.connect(self.on_extent_from_active_layer_button_clicked)
        self.radio_global.setChecked(True)

        self.tree = QListWidget()
        vbox_tree = QVBoxLayout()
        vbox.addLayout(vbox_tree)
        vbox_tree.addWidget(self.tree)

        self.btn_download = QPushButton('Download')
        self.btn_download.clicked.connect(self.on_download_button_clicked)
        vbox.addWidget(self.btn_download)

        self.status_label = QLabel('')
        self.status_label.hide()
        vbox.addWidget(self.status_label)

        self.btn_check_status = QPushButton('Check Status of Last Request')
        self.btn_check_status.hide()
        self.btn_check_status.clicked.connect(self.on_check_status_clicked)
        vbox.addWidget(self.btn_check_status)

        self.progress_bar = QProgressBar()
        self.progress_bar.setRange(0, PROGRESS_BAR_MAX)
        self.progress_bar.setTextVisible(False)
        self.progress_bar.hide()
        vbox.addWidget(self.progress_bar)

        go_to_data_tab_btn = QPushButton('Continue to Datasets')
        go_to_data_tab_btn.clicked.connect(self.go_to_data_tab)
        vbox.addWidget(go_to_data_tab_btn)

    def on_dataset_changed(self, index: int):
        self.cbox_product.clear()
        dataset_name = self.cbox_dataset.currentData()
        if dataset_name is None:
           return
        # Use o token CDS para autenticação
        auth = (self.options.cds_key, '')
        self.products = get_met_products(dataset_name, self.options.cds_key)
        for product in self.products.keys():
           self.cbox_product.addItem(product, product)

    def on_product_changed(self, index: int):
        if index == -1:
            return
        
        self.tree.clear()
        product_name = self.cbox_product.currentData()
        current_avail_vars = self.products[product_name]
        dates = []
        for name in current_avail_vars.keys():
            item = QListWidgetItem(current_avail_vars[name]['label'])
            item.setData(Qt.UserRole, name)
            item.setCheckState(Qt.Checked)
            self.tree.addItem(item)
            dates.append(current_avail_vars[name]['start_date'])
            dates.append(current_avail_vars[name]['end_date'])
        date_min = min(dates)
        date_max = max(dates)

        for dt_input in [self.dedit_start_date, self.dedit_end_date]:
            dt_input.setDateTimeRange(
                QDateTime(QDate(date_min.year, date_min.month, date_min.day), QTime(date_min.hour, date_min.minute)),
                QDateTime(QDate(date_max.year, date_max.month, date_max.day), QTime(date_max.hour, date_max.minute)))

        min_dt = self.dedit_start_date.minimumDateTime()
        max_dt = self.dedit_start_date.maximumDateTime()
        self.dedit_start_date.setDateTime(min_dt)
        self.dedit_end_date.setDateTime(max_dt)

    def on_download_button_clicked(self):
        param_names = []
        for index in range(self.tree.count()):
            item = self.tree.item(index)
            if item.checkState() == Qt.Checked:
                param_name = item.data(Qt.UserRole)
                param_names.append(param_name)

        dataset_name = self.cbox_dataset.currentData()
        product_name = self.cbox_product.currentData()
        start_date = self.dedit_start_date.dateTime().toPyDateTime()
        end_date = self.dedit_end_date.dateTime().toPyDateTime()
        if dataset_name is None or product_name is None:
            raise UserError('Dataset/Product not selected')

        interval_hours = self.spin_interval.value()
        
        args = [self.options.met_dir, dataset_name, product_name, start_date, end_date, interval_hours]
        if is_met_dataset_downloaded(*args):
            reply = QMessageBox.question(self.iface.mainWindow(), 'Existing dataset',
                ('You already downloaded data with the selected dataset/product/date/time combination. '
                 'If you continue, this data will be removed.\n'
                 'Location: {}'.format(get_met_dataset_path(*args))),
                QMessageBox.Ok, QMessageBox.Cancel)
            if reply == QMessageBox.Cancel:
                return

        lat_north = self.top.value()
        lat_south = self.bottom.value()
        lon_west = self.left.value()
        lon_east = self.right.value()
         # Use o token CDS para autenticação
        auth = (self.options.cds_key, '')

        self.last_download_path = get_met_dataset_path(*args)
        self.last_dataset_name = dataset_name
        self.last_product_name = product_name

        thread = TaskThread(
            lambda: download_met_dataset(self.options.met_dir, auth, 
                                         dataset_name, product_name, param_names,
                                         start_date, end_date,
                                         lat_south, lat_north, lon_west, lon_east,
                                         interval_hours=interval_hours),
            yields_progress=True)
        thread.started.connect(self.on_started_download)
        thread.progress.connect(self.on_progress_download)
        thread.finished.connect(self.on_finished_download)
        thread.succeeded.connect(self.on_successful_download)
        thread.failed.connect(reraise)
        thread.start()

    def on_started_download(self) -> None:
        self.btn_download.setEnabled(False)
        self.status_label.show()
        self.btn_check_status.show()
        self.progress_bar.show()
        self.current_req_ids = []
        
    def on_progress_download(self, progress: float, status: str) -> None:
        bar_value = int(progress * PROGRESS_BAR_MAX)
        self.progress_bar.setValue(bar_value)
        self.progress_bar.repaint() # otherwise just updates in 1% steps
        
        self.status_label.setText(status)
        self.status_label.repaint()
        
        if status.startswith("[") and "] " in status:
            req_id = status.split("] ")[0][1:]
            if not hasattr(self, 'current_req_ids'):
                self.current_req_ids = []
            if req_id not in self.current_req_ids:
                self.current_req_ids.append(req_id)

        if status == 'submitted':
            self.msg_bar.info('Met dataset download request submitted successfully, waiting until available for download...')
        elif status == 'ready':
            self.msg_bar.info('Met dataset download request is now ready, downloading...')
        logger.debug(f'Met data download: {progress*100:.1f}% - {status}')

    def on_check_status_clicked(self):
        if not hasattr(self, 'current_req_ids') or not self.current_req_ids:
            QMessageBox.information(self, "Status", "Nenhum Request ID encontrado no processo atual.")
            return
            
        import requests
        
        status_messages = []
        for req_id in self.current_req_ids:
            url = f"https://cds.climate.copernicus.eu/api/retrieve/v1/jobs/{req_id}"
            headers = {
                "Authorization": f"Bearer {self.options.cds_key}"
            }
            try:
                r = requests.get(url, headers=headers, timeout=10)
                data = r.json()
                if r.status_code == 200:
                    status_text = data.get('status', 'unknown')
                    created = data.get('created', 'unknown')
                    status_messages.append(f"Request ID: {req_id}\nStatus: {status_text}\nCreated: {created}\n")
                else:
                    status_messages.append(f"Request ID: {req_id}\nError: {r.status_code} - {data.get('message', '')}\n")
            except Exception as e:
                status_messages.append(f"Request ID: {req_id}\nError checking status: {e}\n")
                
        QMessageBox.information(self, "Copernicus Status", "\n".join(status_messages) + "\nO processo concluiu a submissão, continue acompanhando para download.")
    
    def on_finished_download(self) -> None:
        self.btn_download.setEnabled(True)
        self.status_label.hide()
        self.progress_bar.hide()
    
    def on_successful_download(self) -> None:
        self.msg_bar.success('Meteorological dataset downloaded successfully.')
        Broadcast.met_datasets_updated.emit()
        
        try:
            if getattr(self, 'project', None) is not None and hasattr(self, 'last_download_path'):
                from gis4wrf.core import read_grib_folder_metadata
                meta_all, meta_files = read_grib_folder_metadata(str(self.last_download_path))
                self.project.met_dataset_spec = {
                    'paths': [meta.path for meta in meta_files],
                    'dataset': self.last_dataset_name,
                    'product': self.last_product_name,
                    'time_range': meta_all.time_range,
                    'interval_seconds': meta_all.interval_seconds
                }
                Broadcast.project_updated.emit()
                self.msg_bar.success('As datas do projeto WPS/WRF foram sincronizadas automaticamente com o dataset recém-baixado!')
        except Exception as e:
            logger.error(f"Error auto-linking downloaded dataset: {e}")

    def on_extent_radio_button_clicked(self):
        if self.radio_global.isChecked():
            self.top.set_value(90)
            self.bottom.set_value(-90)
            self.left.set_value(-180)
            self.right.set_value(180)
            self.top.setDisabled(True)
            self.bottom.setDisabled(True)
            self.left.setDisabled(True)
            self.right.setDisabled(True)
            self.widget_extent.hide()

        elif self.radio_subset.isChecked():
            self.widget_extent.show()
            self.top.setDisabled(False)
            self.bottom.setDisabled(False)
            self.left.setDisabled(False)
            self.right.setDisabled(False)
            # Auto-populate if fields are currently at global defaults
            try:
                is_default = (float(self.top.value()) == 90.0 and float(self.bottom.value()) == -90.0 and
                              float(self.left.value()) == -180.0 and float(self.right.value()) == 180.0)
            except:
                is_default = True
            if is_default:
                self.on_extent_from_active_layer_button_clicked()

    def on_extent_from_active_layer_button_clicked(self):
        from qgis.core import QgsProject
        # Target explicitly the largest domain (Domain 1)
        layers = QgsProject.instance().mapLayersByName('Domain 1')
        if layers:
            layer = layers[0]
        else:
            # Fallback to the active layer if Domain 1 is not found
            layer = self.iface.activeLayer()

        if layer is None:
            return
        layer_crs = CRS(layer.crs().toProj4())
        target_crs = CRS('+proj=latlong +datum=WGS84')
        extent = layer.extent() # type: QgsRectangle
        bbox = rect_to_bbox(extent)
        bbox_geo = layer_crs.transform_bbox(bbox, target_crs.srs)
        padding = 5 # degrees
        lat_south = max(bbox_geo.miny - padding, -90)
        lat_north = min(bbox_geo.maxy + padding, 90)
        lon_west = max(bbox_geo.minx - padding, -180)
        lon_east = min(bbox_geo.maxx + padding, 180)
        self.bottom.set_value(lat_south)
        self.top.set_value(lat_north)
        self.left.set_value(lon_west)
        self.right.set_value(lon_east)

    # Ao salvar opções:
    def save_options(self):
        self.options.cds_key = self.cds_key_input.text()
        self.options.save()
