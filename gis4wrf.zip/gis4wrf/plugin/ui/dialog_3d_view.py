# GIS4WRF — dialog_3d_view.py
# Interactive 3-D visualisation for WRF output variables.
#
# Modes
# -----
#   Surface    – variable coloured over terrain (Z = terrain height)
#   Level slices – stacked horizontal planes for 3-D variables
#   Cross cuts – EW curtain + NS curtain simultaneously, each with its own
#                position slider.  Z axis is the vertical/eta level.
#   Contour 2D – fast top-down filled-contour with isolines
#
# Optional overlays
# -----------------
#   Wind vectors – quiver arrows from U10/V10 (or U/V at current level)
#   Terrain base – semi-transparent terrain shown below cross cuts
#
# Controls
# --------
#   NS position slider  – latitude of the East-West curtain
#   EW position slider  – longitude of the North-South curtain
#   Level slider        – eta/pressure level (for Surface + Cuts modes)
#   Time slider         – time step
#   Alpha slider        – surface transparency
#   Vert. exag slider   – vertical exaggeration of terrain height
#   Colormap combo
#   Wind checkbox
#   Terrain base checkbox
#   Save PNG button

from __future__ import annotations
import os
from typing import Optional
import numpy as np

from PyQt5.QtCore import Qt
from PyQt5.QtGui import QGuiApplication
from PyQt5.QtWidgets import (
    QDialog, QVBoxLayout, QHBoxLayout, QPushButton,
    QLabel, QSlider, QComboBox, QCheckBox,
    QGroupBox, QRadioButton, QButtonGroup, QSizePolicy,
    QFileDialog, QMessageBox, QWidget, QGridLayout,
    QScrollArea, QFrame, QListWidget, QListWidgetItem
)

try:
    from qgis.core import (
        QgsProject, QgsMapLayerType, QgsWkbTypes,
        QgsCoordinateReferenceSystem, QgsCoordinateTransform,
        QgsRectangle, QgsFeatureRequest
    )
    HAS_QGIS = True
except ImportError:
    HAS_QGIS = False

try:
    import matplotlib
    matplotlib.use('Qt5Agg')
    from matplotlib.backends.backend_qt5agg import (
        FigureCanvasQTAgg as FigureCanvas,
        NavigationToolbar2QT as NavToolbar
    )
    from matplotlib.figure import Figure
    import matplotlib.cm as cm
    import matplotlib.colors as mcolors
    HAS_MPL = True
except Exception:
    HAS_MPL = False

try:
    from netCDF4 import Dataset as NC4Dataset
    HAS_NC4 = True
except Exception:
    HAS_NC4 = False

# ── colour ramps ──────────────────────────────────────────────────────────────
RAMP_CHOICES = [
    'Spectral_r', 'RdYlBu', 'RdBu', 'Blues', 'Viridis',
    'Magma', 'Plasma', 'YlOrRd', 'BuGn', 'PuOr', 'terrain', 'rainbow',
    'coolwarm', 'jet', 'hsv', 'bwr'
]

MODE_SURFACE  = 'surface'
MODE_LEVELS   = 'levels'
MODE_CUTS     = 'cuts'
MODE_CONTOUR  = 'contour2d'


class View3DDialog(QDialog):
    """Interactive 3-D / 2-D visualisation of a WRF variable."""

    def __init__(
        self,
        dataset_path: str,
        var_name: str,
        var_description: str,
        var_units: str,
        time_idx: int,
        extra_dim_idx: Optional[int],
        times: list,
        cmap_name: str = 'Spectral_r',
        parent=None
    ):
        super().__init__(parent)
        self.setWindowFlags(self.windowFlags() | Qt.WindowMaximizeButtonHint | Qt.WindowMinimizeButtonHint)
        self.dataset_path = dataset_path
        self.var_name     = var_name
        self.var_desc     = var_description
        self.var_units    = var_units
        self.time_idx     = time_idx
        self.level_idx    = extra_dim_idx or 0
        self.times        = times
        self.cmap_name    = cmap_name

        # State
        self._mode        = MODE_SURFACE
        self._alpha       = 0.9
        self._vert_exag   = 100     # terrain vertical exaggeration
        self._ns_pos      = 0.5     # fraction 0-1 → latitude of EW curtain
        self._ew_pos      = 0.5     # fraction 0-1 → longitude of NS curtain
        self._show_terrain= True
        self._show_wind   = False
        self._filter_min  = 0.0
        self._filter_max  = 1.0
        self._zoom_factor = 1.0
        self._data_cache: dict = {}

        self.setWindowTitle(f'3D View — {var_name}  ({var_description})')
        geom = QGuiApplication.primaryScreen().geometry()
        self.resize(int(geom.width() * 0.70), int(geom.height() * 0.80))

        if not HAS_MPL or not HAS_NC4:
            missing = 'matplotlib' if not HAS_MPL else 'netCDF4'
            lay = QVBoxLayout()
            lay.addWidget(QLabel(f'❌  {missing} not found – cannot open 3D view.'))
            self.setLayout(lay)
            return

        try:
            self._load_nc()
        except Exception as exc:
            lay = QVBoxLayout()
            lay.addWidget(QLabel(f'❌  Error loading data:\n{exc}'))
            self.setLayout(lay)
            return

        self._build_ui()
        self._update_plot()

    # ── data loading ──────────────────────────────────────────────────────────

    def _load_nc(self) -> None:
        with NC4Dataset(self.dataset_path) as ds:
            def _read(name):
                v = ds.variables.get(name)
                return np.squeeze(np.array(v[:])) if v is not None else None

            xlat  = _read('XLAT')
            xlong = _read('XLONG')
            if xlat is not None and xlat.ndim == 3:
                xlat, xlong = xlat[0], xlong[0]

            self.lats    = xlat
            self.lons    = xlong
            self.terrain = None
            hgt = ds.variables.get('HGT')
            if hgt is not None:
                self.terrain = np.squeeze(np.array(hgt[0]))

            landmask = ds.variables.get('LANDMASK')
            if landmask is not None:
                self.landmask = np.squeeze(np.array(landmask[0]))
            else:
                self.landmask = None

            if not hasattr(self, 'all_vars'):
                self.all_vars = [name for name, val in ds.variables.items() if hasattr(val, 'ndim') and val.ndim >= 3]

            v = ds.variables.get(self.var_name)
            if v is None:
                raise KeyError(f'"{self.var_name}" not found')
            raw = np.ma.filled(np.array(v[:]), np.nan)

            self.var_all  = raw
            self.is_3d    = raw.ndim == 4
            self.n_times  = raw.shape[0]
            self.n_levs   = raw.shape[1] if self.is_3d else 1

            # Pre-load wind if available
            self._has_wind = False
            for uname, vname in [('U10','V10'), ('U','V')]:
                uu = ds.variables.get(uname)
                vv = ds.variables.get(vname)
                if uu is not None and vv is not None:
                    self._wind_u = np.array(uu[:])
                    self._wind_v = np.array(vv[:])
                    self._wind_3d = self._wind_u.ndim == 4
                    self._has_wind = True
                    break

    def _get_2d_slice(self) -> np.ndarray:
        key = (self.time_idx, self.level_idx)
        if key not in self._data_cache:
            sl = self.var_all[self.time_idx, self.level_idx] if self.is_3d \
                 else self.var_all[self.time_idx]
            if sl.ndim == 3:
                sl = sl[..., 0]
            self._data_cache[key] = sl
        return self._data_cache[key]

    def _coords(self, ny=None, nx=None):
        sl = self._get_2d_slice()
        ny = ny or sl.shape[0]
        nx = nx or sl.shape[1]
        if self.lons is not None:
            return self.lons[:ny, :nx], self.lats[:ny, :nx]
        X = np.arange(nx)[np.newaxis, :] * np.ones((ny, 1))
        Y = np.arange(ny)[:, np.newaxis] * np.ones((1, nx))
        return X, Y

    def _sub(self, *arrays, n=70):
        """Subsample 2-D arrays to n×n for speed."""
        ny, nx = arrays[0].shape[:2]
        sy, sx = max(1, ny // n), max(1, nx // n)
        return tuple(a[::sy, ::sx] for a in arrays)

    # ── UI ────────────────────────────────────────────────────────────────────

    def _build_ui(self) -> None:
        root = QHBoxLayout(self)
        root.setSpacing(4)
        root.setContentsMargins(4, 4, 4, 4)

        # ── control strip (scrollable) ────────────────────────────────────────
        strip = QWidget()
        strip_lay = QVBoxLayout(strip)
        strip_lay.setSpacing(8)

        # ── Mode ──────────────────────────────────────────────────────────────
        mode_box = QGroupBox('Mode')
        mode_lay = QVBoxLayout(mode_box)
        self._mode_group = QButtonGroup(self)
        for label, mode in [('🗺 Surface',       MODE_SURFACE),
                             ('📚 Level slices',  MODE_LEVELS),
                             ('✂️ Cross cuts',     MODE_CUTS),
                             ('📐 Contour 2D',    MODE_CONTOUR)]:
            rb = QRadioButton(label)
            rb.setChecked(mode == self._mode)
            if not self.is_3d and mode in (MODE_LEVELS, MODE_CUTS):
                rb.setEnabled(False)
            rb.toggled.connect(lambda on, m=mode: self._on_mode(m) if on else None)
            self._mode_group.addButton(rb)
            mode_lay.addWidget(rb)

        self._chk_terrain = QCheckBox('🏔 Terrain base')
        self._chk_terrain.setChecked(self._show_terrain)
        self._chk_terrain.toggled.connect(self._on_terrain_toggle)
        mode_lay.addWidget(self._chk_terrain)

        self._chk_coast = QCheckBox('🗺 Coastlines')
        self._chk_coast.setChecked(False)
        self._chk_coast.setEnabled(getattr(self, 'landmask', None) is not None)
        self._chk_coast.toggled.connect(self._on_coast_toggle)
        mode_lay.addWidget(self._chk_coast)

        self._chk_wind = QCheckBox('💨 Wind vectors')
        self._chk_wind.setChecked(False)
        self._chk_wind.setEnabled(self._has_wind)
        if not self._has_wind:
            self._chk_wind.setToolTip('U10/V10 not found in this file')
        self._chk_wind.toggled.connect(self._on_wind_toggle)
        mode_lay.addWidget(self._chk_wind)
        strip_lay.addWidget(mode_box)

        # ── Cross-section positions ───────────────────────────────────────────
        cuts_box = QGroupBox('Cross-section position')
        cuts_lay = QGridLayout(cuts_box)

        cuts_lay.addWidget(QLabel('EW cut\n(N↔S pos.):'), 0, 0)
        self._ns_label  = QLabel(f'{int(self._ns_pos*100)} %')
        self._ns_slider = QSlider(Qt.Horizontal)
        self._ns_slider.setRange(0, 100)
        self._ns_slider.setValue(int(self._ns_pos * 100))
        self._ns_slider.setTickPosition(QSlider.TicksBelow)
        self._ns_slider.setTickInterval(10)
        self._ns_slider.valueChanged.connect(self._on_ns)
        cuts_lay.addWidget(self._ns_slider, 0, 1)
        cuts_lay.addWidget(self._ns_label,  0, 2)

        cuts_lay.addWidget(QLabel('NS cut\n(E↔W pos.):'), 1, 0)
        self._ew_label  = QLabel(f'{int(self._ew_pos*100)} %')
        self._ew_slider = QSlider(Qt.Horizontal)
        self._ew_slider.setRange(0, 100)
        self._ew_slider.setValue(int(self._ew_pos * 100))
        self._ew_slider.setTickPosition(QSlider.TicksBelow)
        self._ew_slider.setTickInterval(10)
        self._ew_slider.valueChanged.connect(self._on_ew)
        cuts_lay.addWidget(self._ew_slider, 1, 1)
        cuts_lay.addWidget(self._ew_label,  1, 2)

        strip_lay.addWidget(cuts_box)

        # ── Time + Level ──────────────────────────────────────────────────────
        tl_box = QGroupBox('Time / Level')
        tl_lay = QVBoxLayout(tl_box)

        self._time_label  = QLabel(self.times[self.time_idx] if self.times else '—')
        self._time_label.setStyleSheet('color:#88ccff; font-size:10px;')
        self._time_slider = QSlider(Qt.Horizontal)
        self._time_slider.setRange(0, max(0, len(self.times) - 1))
        self._time_slider.setValue(self.time_idx)
        self._time_slider.setTickPosition(QSlider.TicksBelow)
        self._time_slider.setTickInterval(max(1, len(self.times)//10))
        self._time_slider.valueChanged.connect(self._on_time)
        tl_lay.addWidget(QLabel('Time step:'))
        tl_lay.addWidget(self._time_label)
        tl_lay.addWidget(self._time_slider)

        self._lev_label  = QLabel(f'Level: {self.level_idx}')
        self._lev_slider = QSlider(Qt.Horizontal)
        self._lev_slider.setRange(0, max(0, self.n_levs - 1))
        self._lev_slider.setValue(self.level_idx)
        self._lev_slider.setEnabled(self.is_3d)
        self._lev_slider.setTickPosition(QSlider.TicksBelow)
        self._lev_slider.setTickInterval(max(1, self.n_levs // 10))
        self._lev_slider.valueChanged.connect(self._on_level)
        tl_lay.addWidget(QLabel('Vertical level:'))
        tl_lay.addWidget(self._lev_label)
        tl_lay.addWidget(self._lev_slider)
        strip_lay.addWidget(tl_box)

        # ── Appearance ────────────────────────────────────────────────────────
        app_box = QGroupBox('Appearance')
        app_lay = QGridLayout(app_box)

        app_lay.addWidget(QLabel('Variable:'), 0, 0)
        self._var_combo = QComboBox()
        if hasattr(self, 'all_vars'):
            self._var_combo.addItems(self.all_vars)
            self._var_combo.setCurrentText(self.var_name)
        self._var_combo.currentTextChanged.connect(self._on_var_changed)
        app_lay.addWidget(self._var_combo, 0, 1, 1, 2)

        app_lay.addWidget(QLabel('Colormap:'), 1, 0)
        self._cmap_combo = QComboBox()
        for n in RAMP_CHOICES:
            self._cmap_combo.addItem(n)
        cin = self.cmap_name if self.cmap_name in RAMP_CHOICES else 'Spectral_r'
        self._cmap_combo.setCurrentText(cin)
        self._cmap_combo.currentTextChanged.connect(self._on_cmap)
        app_lay.addWidget(self._cmap_combo, 1, 1, 1, 2)

        app_lay.addWidget(QLabel('Transparency:'), 2, 0)
        self._alpha_slider = QSlider(Qt.Horizontal)
        self._alpha_slider.setRange(5, 100)
        self._alpha_slider.setValue(int(self._alpha * 100))
        self._alpha_slider.setTickPosition(QSlider.TicksBelow)
        self._alpha_slider.setTickInterval(10)
        self._alpha_label = QLabel(f'{int(self._alpha*100)} %')
        self._alpha_slider.valueChanged.connect(self._on_alpha)
        app_lay.addWidget(self._alpha_slider, 2, 1)
        app_lay.addWidget(self._alpha_label, 2, 2)

        app_lay.addWidget(QLabel('Vert. exag ×:'), 3, 0)
        self._vexag_slider = QSlider(Qt.Horizontal)
        self._vexag_slider.setRange(1, 500)
        self._vexag_slider.setValue(self._vert_exag)
        self._vexag_slider.setTickPosition(QSlider.TicksBelow)
        self._vexag_slider.setTickInterval(50)
        self._vexag_label = QLabel(f'× {self._vert_exag}')
        self._vexag_slider.valueChanged.connect(self._on_vexag)
        app_lay.addWidget(self._vexag_slider, 3, 1)
        app_lay.addWidget(self._vexag_label, 3, 2)

        app_lay.addWidget(QLabel('Filter Min %:'), 4, 0)
        self._fmin_slider = QSlider(Qt.Horizontal)
        self._fmin_slider.setRange(0, 100)
        self._fmin_slider.setValue(int(self._filter_min * 100))
        self._fmin_slider.setTickPosition(QSlider.TicksBelow)
        self._fmin_slider.setTickInterval(10)
        self._fmin_label = QLabel(f'{int(self._filter_min*100)} %')
        self._fmin_slider.valueChanged.connect(self._on_fmin)
        app_lay.addWidget(self._fmin_slider, 4, 1)
        app_lay.addWidget(self._fmin_label, 4, 2)

        app_lay.addWidget(QLabel('Filter Max %:'), 5, 0)
        self._fmax_slider = QSlider(Qt.Horizontal)
        self._fmax_slider.setRange(0, 100)
        self._fmax_slider.setValue(int(self._filter_max * 100))
        self._fmax_slider.setTickPosition(QSlider.TicksBelow)
        self._fmax_slider.setTickInterval(10)
        self._fmax_label = QLabel(f'{int(self._filter_max*100)} %')
        self._fmax_slider.valueChanged.connect(self._on_fmax)
        app_lay.addWidget(self._fmax_slider, 5, 1)
        app_lay.addWidget(self._fmax_label, 5, 2)

        app_lay.addWidget(QLabel('Zoom:'), 6, 0)
        self._zoom_slider = QSlider(Qt.Horizontal)
        self._zoom_slider.setRange(50, 300)
        self._zoom_slider.setValue(int(self._zoom_factor * 100))
        self._zoom_slider.setTickPosition(QSlider.TicksBelow)
        self._zoom_slider.setTickInterval(50)
        self._zoom_label = QLabel(f'{int(self._zoom_factor*100)} %')
        self._zoom_slider.valueChanged.connect(self._on_zoom)
        app_lay.addWidget(self._zoom_slider, 6, 1)
        app_lay.addWidget(self._zoom_label, 6, 2)

        self.chk_autorotate = QCheckBox('Auto Rotate')
        self.chk_autorotate.toggled.connect(self._on_autorotate_toggled)
        app_lay.addWidget(self.chk_autorotate, 7, 0, 1, 3)

        save_btn = QPushButton('💾 Save PNG')
        save_btn.clicked.connect(self._export_png)
        app_lay.addWidget(save_btn, 8, 0, 1, 3)
        
        export_py_btn = QPushButton('📜 Export Python Script')
        export_py_btn.clicked.connect(self._export_python_script)
        app_lay.addWidget(export_py_btn, 9, 0, 1, 3)
        strip_lay.addWidget(app_box)

        # ── Vector Overlays ───────────────────────────────────────────────────
        if HAS_QGIS:
            vec_box = QGroupBox('Vector Overlays')
            vec_lay = QVBoxLayout(vec_box)
            self._vector_list = QListWidget()
            self._vector_list.setSelectionMode(QListWidget.NoSelection)
            self._vector_layers_map = {}
            for layer in QgsProject.instance().mapLayers().values():
                if layer.type() == QgsMapLayerType.VectorLayer:
                    item = QListWidgetItem(layer.name())
                    item.setFlags(item.flags() | Qt.ItemIsUserCheckable)
                    item.setCheckState(Qt.Unchecked)
                    self._vector_list.addItem(item)
                    self._vector_layers_map[layer.name()] = layer
            self._vector_list.itemChanged.connect(self._on_vector_changed)
            vec_lay.addWidget(self._vector_list)
            strip_lay.addWidget(vec_box)

        strip_lay.addStretch()
        
        scroll = QScrollArea()
        scroll.setWidgetResizable(True)
        scroll.setWidget(strip)
        scroll.setFixedWidth(280)

        # ── canvas ───────────────────────────────────────────────────────────
        self.fig    = Figure(facecolor='#1a1a2e', tight_layout=True)
        self.canvas = FigureCanvas(self.fig)
        self.canvas.setSizePolicy(QSizePolicy.Expanding, QSizePolicy.Expanding)
        nav = NavToolbar(self.canvas, self)
        nav.setStyleSheet('background:#1a1a2e; color:white;')
        
        plot_widget = QWidget()
        plot_lay = QVBoxLayout(plot_widget)
        plot_lay.setContentsMargins(0, 0, 0, 0)
        plot_lay.addWidget(nav)
        plot_lay.addWidget(self.canvas)

        root.addWidget(scroll)
        root.addWidget(plot_widget)

    # ── plotting dispatcher ───────────────────────────────────────────────────

    def _update_plot(self) -> None:
        self.fig.clear()
        try:
            if   self._mode == MODE_SURFACE:  self._plot_surface()
            elif self._mode == MODE_LEVELS:   self._plot_levels()
            elif self._mode == MODE_CUTS:     self._plot_both_cuts()
            elif self._mode == MODE_CONTOUR:  self._plot_contour2d()
        except Exception as exc:
            ax = self.fig.add_subplot(111)
            ax.set_facecolor('#1a1a2e')
            ax.text(0.5, 0.5, f'Plot error:\n{exc}',
                    transform=ax.transAxes, ha='center', va='center',
                    color='#ff6b6b', fontsize=10)
        self.canvas.draw()

    def _cmap_obj(self):
        return cm.get_cmap(self._cmap_combo.currentText())

    def _norm(self, data):
        vmin = np.nanpercentile(data, 2)
        vmax = np.nanpercentile(data, 98)
        if vmin == vmax:
            vmax = vmin + 1
        return mcolors.Normalize(vmin, vmax), vmin, vmax

    def _make_ax3d(self, title_extra=''):
        ax = self.fig.add_subplot(111, projection='3d')
        ax.set_facecolor('#0d0d1a')
        self.fig.patch.set_facecolor('#1a1a2e')
        for pane in (ax.xaxis.pane, ax.yaxis.pane, ax.zaxis.pane):
            pane.fill = False
            pane.set_edgecolor('#333')
        ax.tick_params(colors='#aaa', labelsize=7)
        for axis in (ax.xaxis, ax.yaxis, ax.zaxis):
            axis.label.set_color('#ccc')
        t_str = self.times[self.time_idx] if self.times else ''
        ax.set_title(
            f'{self.var_name}  [{self.var_units}]  —  {t_str} {title_extra}',
            color='white', fontsize=10, pad=8
        )
        try:
            ax.set_box_aspect((1, 1, 0.4))
        except Exception:
            pass
            
        if hasattr(ax, 'dist'):
            ax.dist = 10.0 / getattr(self, '_zoom_factor', 1.0)
            
        try:
            self.fig.subplots_adjust(left=0.05, right=0.95, bottom=0.05, top=0.95)
        except Exception:
            pass
            
        return ax

    def _make_ax2d(self):
        ax = self.fig.add_subplot(111)
        ax.set_facecolor('#0d0d1a')
        self.fig.patch.set_facecolor('#1a1a2e')
        ax.tick_params(colors='#aaa', labelsize=8)
        ax.xaxis.label.set_color('#ccc')
        ax.yaxis.label.set_color('#ccc')
        ax.spines[:].set_color('#555')
        t_str = self.times[self.time_idx] if self.times else ''
        ax.set_title(f'{self.var_name}  [{self.var_units}]  —  {t_str}',
                     color='white', fontsize=10)
        return ax

    def _add_colorbar(self, ax, cmap, norm, vmin, vmax):
        sm = cm.ScalarMappable(cmap=cmap, norm=norm)
        sm.set_array([])
        cb = self.fig.colorbar(sm, ax=ax, shrink=0.55, pad=0.08,
                                fraction=0.03, orientation='vertical')
        cb.set_label(f'{self.var_name} [{self.var_units}]', color='#ccc', fontsize=8)
        cb.ax.yaxis.set_tick_params(color='#aaa', labelsize=7)
        for lbl in cb.ax.get_yticklabels():
            lbl.set_color('#aaa')

    # ── Surface mode ──────────────────────────────────────────────────────────

    def _plot_surface(self) -> None:
        data = self._get_2d_slice()
        ny, nx = data.shape
        lons, lats = self._coords(ny, nx)
        terrain = (self.terrain[:ny, :nx] if self.terrain is not None
                   else np.zeros_like(data))

        data_s, lons_s, lats_s, terr_s = self._sub(data, lons, lats, terrain)

        cmap = self._cmap_obj()
        norm, vmin, vmax = self._norm(data_s)
        norm_data = norm(np.nan_to_num(data_s, nan=vmin))
        colors = cmap(norm_data)
        if hasattr(self, '_filter_min') and self._filter_min > 0:
            colors[norm_data < self._filter_min, 3] = 0.0
        if hasattr(self, '_filter_max') and self._filter_max < 1.0:
            colors[norm_data > self._filter_max, 3] = 0.0

        ax = self._make_ax3d(f'  (level {self.level_idx})' if self.is_3d else '')
        ax.plot_surface(lons_s, lats_s, terr_s * self._vert_exag,
                        facecolors=colors, shade=True,
                        alpha=self._alpha, linewidth=0, antialiased=True)

        ax.set_xlabel('Longitude' if self.lons is not None else 'X')
        ax.set_ylabel('Latitude'  if self.lats is not None else 'Y')
        ax.set_zlabel(f'Height × {self._vert_exag}')

        if self._show_wind and self._has_wind:
            self._add_wind_quiver(ax, terr_s * self._vert_exag, lons_s, lats_s)

        if hasattr(self, '_chk_coast') and self._chk_coast.isChecked() and getattr(self, 'landmask', None) is not None:
            try:
                mask_s = self._sub(self.landmask[:ny, :nx])[0]
                z_offset = np.min(terr_s * self._vert_exag)
                ax.contour(lons_s, lats_s, mask_s, levels=[0.5], colors='white', linewidths=1.0, zdir='z', offset=z_offset)
            except Exception:
                pass

        self._add_vector_overlays(ax, lons_s, lats_s, terr_s * self._vert_exag)
        
        self._add_colorbar(ax, cmap, norm, vmin, vmax)

    # ── Level slices mode ─────────────────────────────────────────────────────

    def _plot_levels(self) -> None:
        if not self.is_3d:
            raise ValueError('Level slices requires a 3-D variable')

        t  = self.time_idx
        nl = self.var_all.shape[1]
        ny, nx = self.var_all.shape[2], self.var_all.shape[3]
        lons, lats = self._coords(ny, nx)

        lev_indices = np.linspace(0, nl - 1, min(nl, 7), dtype=int)
        cmap = self._cmap_obj()
        norm, vmin, vmax = self._norm(self.var_all[t])

        ax = self._make_ax3d()
        z_max = 1000.0  # arbitrary height units

        for ilev in lev_indices:
            sl = self.var_all[t, ilev, :ny, :nx]
            sl_s, lons_s, lats_s = self._sub(sl, lons, lats)
            z_val = (ilev / max(nl - 1, 1)) * z_max
            norm_data = norm(np.nan_to_num(sl_s, nan=vmin))
            colors = cmap(norm_data)
            if hasattr(self, '_filter_min') and self._filter_min > 0:
                colors[norm_data < self._filter_min, 3] = 0.0
            if hasattr(self, '_filter_max') and self._filter_max < 1.0:
                colors[norm_data > self._filter_max, 3] = 0.0
                
            ax.plot_surface(lons_s, lats_s, np.full_like(lons_s, z_val),
                            facecolors=colors, shade=False,
                            alpha=max(0.05, self._alpha * 0.55),
                            linewidth=0, antialiased=True)

            if self._show_wind and self._has_wind:
                self._add_wind_quiver(ax, np.full_like(lons_s, z_val), lons_s, lats_s, level_idx=ilev)

        ax.set_xlabel('Longitude' if self.lons is not None else 'X')
        ax.set_ylabel('Latitude'  if self.lats is not None else 'Y')
        ax.set_zlabel('Eta level (0 = surface, 1000 = top)')
        self._add_colorbar(ax, cmap, norm, vmin, vmax)

    # ── Both cuts mode (correct 3-D orientation) ──────────────────────────────

    def _plot_both_cuts(self) -> None:
        if not self.is_3d:
            raise ValueError('Cross cuts requires a 3-D variable')

        t  = self.time_idx
        nl = self.var_all.shape[1]
        ny, nx = self.var_all.shape[2], self.var_all.shape[3]
        lons, lats = self._coords(ny, nx)

        cmap  = self._cmap_obj()
        norm, vmin, vmax = self._norm(self.var_all[t])
        ax    = self._make_ax3d()

        # Level heights: level 0 at Z=0 (surface), level nl-1 at Z=1
        # multiplied by vert_exag to give sensible visual scale
        lev_z = np.linspace(0, self._vert_exag * 1.0, nl)

        # ── EW curtain (fixed NS position → fixed latitude row iy) ──────────
        iy = max(0, min(ny - 1, int(self._ns_pos * (ny - 1))))
        lon_row  = lons[iy, :]            # (WE,)
        lat_val  = lats[iy, 0] if self.lats is not None else float(iy)
        data_ew  = self.var_all[t, :, iy, :]  # (nl, WE)

        step_x = max(1, nx // 60)
        lon_s   = lon_row[::step_x]       # subsampled lon
        data_ews = data_ew[:, ::step_x]   # (nl, nx_s)

        LON_ew, LEV_ew = np.meshgrid(lon_s, lev_z)
        LAT_ew = np.full_like(LON_ew, lat_val)
        norm_ew = norm(np.nan_to_num(data_ews, nan=vmin))
        col_ew  = cmap(norm_ew)
        if hasattr(self, '_filter_min') and self._filter_min > 0:
            col_ew[norm_ew < self._filter_min, 3] = 0.0
        if hasattr(self, '_filter_max') and self._filter_max < 1.0:
            col_ew[norm_ew > self._filter_max, 3] = 0.0
            
        ax.plot_surface(LON_ew, LAT_ew, LEV_ew,
                        facecolors=col_ew, shade=False,
                        alpha=self._alpha, linewidth=0, antialiased=True)

        # ── NS curtain (fixed EW position → fixed longitude column ix) ───────
        ix = max(0, min(nx - 1, int(self._ew_pos * (nx - 1))))
        lat_col  = lats[:, ix]            # (SN,)
        lon_val  = lons[0, ix] if self.lons is not None else float(ix)
        data_ns  = self.var_all[t, :, :, ix]  # (nl, SN)

        step_y = max(1, ny // 60)
        lat_s   = lat_col[::step_y]
        data_nss = data_ns[:, ::step_y]

        LAT_ns, LEV_ns = np.meshgrid(lat_s, lev_z)
        LON_ns = np.full_like(LAT_ns, lon_val)
        norm_ns = norm(np.nan_to_num(data_nss, nan=vmin))
        col_ns  = cmap(norm_ns)
        if hasattr(self, '_filter_min') and self._filter_min > 0:
            col_ns[norm_ns < self._filter_min, 3] = 0.0
        if hasattr(self, '_filter_max') and self._filter_max < 1.0:
            col_ns[norm_ns > self._filter_max, 3] = 0.0
            
        ax.plot_surface(LON_ns, LAT_ns, LEV_ns,
                        facecolors=col_ns, shade=False,
                        alpha=self._alpha, linewidth=0, antialiased=True)

        # ── Optional terrain base ─────────────────────────────────────────────
        if self._show_terrain and self.terrain is not None:
            terr = self.terrain[:ny, :nx]
            terr_n  = (terr - terr.min()) / max(terr.max() - terr.min(), 1)
            terr_s, lons_s, lats_s = self._sub(terr_n * self._vert_exag * 0.15,
                                                lons, lats)
            terrain_cmap = cm.get_cmap('terrain')
            t_col = terrain_cmap(terr_s / max(terr_s.max(), 1e-6))
            ax.plot_surface(lons_s, lats_s, terr_s,
                            facecolors=t_col, shade=True,
                            alpha=0.35, linewidth=0, antialiased=False)

        # ── Intersection lines ────────────────────────────────────────────────
        ax.plot([lon_row[0],  lon_row[-1]],  [lat_val, lat_val],
                [0, 0], '--', color='#ffff00', lw=0.8, alpha=0.7)
        ax.plot([lon_val,  lon_val],  [lat_col[0], lat_col[-1]],
                [0, 0], '--', color='#00ffff', lw=0.8, alpha=0.7)

        ax.set_xlabel('Longitude' if self.lons is not None else 'X')
        ax.set_ylabel('Latitude'  if self.lats is not None else 'Y')
        ax.set_zlabel('Eta level (0=surface → top)')

        if self._show_wind and self._has_wind:
            # quiver at multiple levels
            lo_s, la_s = self._sub(lons, lats, n=15)
            lev_indices = np.linspace(0, nl - 1, min(nl, 7), dtype=int)
            for ilev in lev_indices:
                z_val = (ilev / max(nl - 1, 1)) * self._vert_exag * 1.0
                z_s = np.full_like(lo_s, z_val)
                self._add_wind_quiver(ax, z_s, lo_s, la_s, level_idx=ilev)

        self._add_colorbar(ax, cmap, norm, vmin, vmax)

    # ── Contour 2D mode ───────────────────────────────────────────────────────

    def _plot_contour2d(self) -> None:
        data = self._get_2d_slice()
        ny, nx = data.shape
        lons, lats = self._coords(ny, nx)

        # Use full resolution (matplotlib handles 2D contours efficiently)
        cmap = self._cmap_obj()
        norm, vmin, vmax = self._norm(data)
        data_clean = np.nan_to_num(data, nan=vmin)

        ax = self._make_ax2d()

        # Filled contour
        cf = ax.contourf(lons, lats, data_clean, levels=20,
                         cmap=cmap, norm=norm, alpha=self._alpha,
                         extend='both')
        cs = ax.contour(lons, lats, data_clean, levels=10,
                        colors='white', linewidths=0.4, alpha=0.6)
        ax.clabel(cs, inline=True, fontsize=6, fmt='%.1f',
                  colors='white', use_clabeltext=True)

        if hasattr(self, '_chk_coast') and self._chk_coast.isChecked() and getattr(self, 'landmask', None) is not None:
            try:
                ax.contour(lons, lats, self.landmask[:ny, :nx], levels=[0.5], colors='black', linewidths=1.0)
            except Exception:
                pass

        if self._show_wind and self._has_wind:
            step = max(1, min(ny, nx) // 15)
            lo_s, la_s = lons[::step, ::step], lats[::step, ::step]
            u_s, v_s = self._get_wind_slice(ny, nx, step)
            if u_s is not None:
                spd = np.hypot(u_s, v_s)
                ax.quiver(lo_s, la_s, u_s, v_s,
                          spd, cmap='Greys_r', alpha=0.85,
                          scale=None, width=0.003)

        self._add_vector_overlays(ax, lons, lats, None)

        ax.set_xlabel('Longitude' if self.lons is not None else 'X')
        ax.set_ylabel('Latitude'  if self.lats is not None else 'Y')

        # Dummy ScalarMappable for colorbar
        sm = cm.ScalarMappable(cmap=cmap, norm=norm)
        cb = self.fig.colorbar(sm, ax=ax, pad=0.02, fraction=0.04)
        cb.set_label(f'{self.var_name} [{self.var_units}]', color='#ccc', fontsize=8)
        for lbl in cb.ax.get_yticklabels():
            lbl.set_color('#aaa')

    # ── Wind helpers ──────────────────────────────────────────────────────────

    def _get_wind_slice(self, ny, nx, step=1, level_idx=None):
        """Return (u_s, v_s) subsampled wind slices or (None, None)."""
        if level_idx is None:
            level_idx = self.level_idx
        try:
            if self._wind_3d:
                u = self._wind_u[self.time_idx, level_idx]
                v = self._wind_v[self.time_idx, level_idx]
            else:
                u = self._wind_u[self.time_idx]
                v = self._wind_v[self.time_idx]
            # Destagger WRF U (WE_stag) and V (SN_stag)
            if u.ndim == 2:
                if u.shape[1] != nx:
                    u = 0.5 * (u[:, :-1] + u[:, 1:])
                if v.shape[0] != ny:
                    v = 0.5 * (v[:-1, :] + v[1:, :])
            u = u[:ny:step, :nx:step]
            v = v[:ny:step, :nx:step]
            return u, v
        except Exception:
            return None, None

    def _add_wind_quiver(self, ax, z_surf, lons_s, lats_s, level_idx=None) -> None:
        ny_s, nx_s = lons_s.shape
        u_s, v_s = self._get_wind_slice(
            self.var_all.shape[-2], self.var_all.shape[-1],
            step=max(1, min(self.var_all.shape[-2],
                            self.var_all.shape[-1]) // 15),
            level_idx=level_idx
        )
        if u_s is None:
            return
        # Clip to lons_s shape
        u_s = u_s[:ny_s, :nx_s]
        v_s = v_s[:ny_s, :nx_s]
        w_s = np.zeros_like(u_s)
        ax.quiver(lons_s, lats_s, z_surf,
                  u_s, v_s, w_s,
                  length=0.4, normalize=False,
                  color='white', alpha=0.85,
                  linewidth=0.6, arrow_length_ratio=0.35)

    def _add_vector_overlays(self, ax, lons, lats, z_surf) -> None:
        if not HAS_QGIS or not hasattr(self, '_vector_list'):
            return
            
        min_lon, max_lon = float(np.min(lons)), float(np.max(lons))
        min_lat, max_lat = float(np.min(lats)), float(np.max(lats))
        rect = QgsRectangle(min_lon, min_lat, max_lon, max_lat)
        
        from scipy.interpolate import griddata
        if z_surf is not None:
            points = np.column_stack((lons.flatten(), lats.flatten()))
            values = z_surf.flatten()
            z_offset = (np.max(values) - np.min(values)) * 0.05
            if z_offset == 0:
                z_offset = 0.5
        
        for i in range(self._vector_list.count()):
            item = self._vector_list.item(i)
            if item.checkState() == Qt.Checked:
                layer = self._vector_layers_map[item.text()]
                
                crsSrc = layer.crs()
                crsDest = QgsCoordinateReferenceSystem("EPSG:4326")
                transform = QgsCoordinateTransform(crsSrc, crsDest, QgsProject.instance())
                
                try:
                    inv_transform = QgsCoordinateTransform(crsDest, crsSrc, QgsProject.instance())
                    req_rect = inv_transform.transformBoundingBox(rect)
                    request = QgsFeatureRequest().setFilterRect(req_rect)
                except Exception:
                    request = QgsFeatureRequest()
                
                for feat in layer.getFeatures(request):
                    geom = feat.geometry()
                    if geom.isNull():
                        continue
                    try:
                        geom.transform(transform)
                    except Exception:
                        continue
                        
                    if geom.type() == QgsWkbTypes.LineGeometry:
                        lines = geom.asMultiPolyline() if geom.isMultipart() else [geom.asPolyline()]
                    elif geom.type() == QgsWkbTypes.PolygonGeometry:
                        lines = []
                        if geom.isMultipart():
                            for poly in geom.asMultiPolygon():
                                lines.extend(poly)
                        else:
                            lines.extend(geom.asPolygon())
                    elif geom.type() == QgsWkbTypes.PointGeometry:
                        pts = geom.asMultiPoint() if geom.isMultipart() else [geom.asPoint()]
                        lines = [pts]
                    else:
                        continue
                        
                    for line in lines:
                        if not line:
                            continue
                        xs = np.array([pt.x() for pt in line])
                        ys = np.array([pt.y() for pt in line])
                        
                        if z_surf is None:
                            # 2D Contour mode
                            ax.plot(xs, ys, color='white', linewidth=1.0, alpha=0.8)
                        else:
                            # 3D modes
                            zs = griddata(points, values, (xs, ys), method='nearest')
                            ax.plot(xs, ys, zs + z_offset, color='white', linewidth=1.5, alpha=0.9)

    # ── event handlers ────────────────────────────────────────────────────────

    def _on_mode(self, mode: str) -> None:
        self._mode = mode
        self._update_plot()

    def _on_terrain_toggle(self, checked: bool) -> None:
        self._show_terrain = checked
        self._update_plot()

    def _on_wind_toggle(self, checked: bool) -> None:
        self._show_wind = checked
        self._update_plot()

    def _on_ns(self, val: int) -> None:
        self._ns_pos = val / 100.0
        self._ns_label.setText(f'{val} %')
        if self._mode == MODE_CUTS:
            self._update_plot()

    def _on_ew(self, val: int) -> None:
        self._ew_pos = val / 100.0
        self._ew_label.setText(f'{val} %')
        if self._mode == MODE_CUTS:
            self._update_plot()

    def _on_time(self, idx: int) -> None:
        self.time_idx = idx
        self._data_cache.clear()
        if self.times:
            self._time_label.setText(self.times[idx])
        self._update_plot()

    def _on_level(self, idx: int) -> None:
        self.level_idx = idx
        self._lev_label.setText(f'Level: {idx}')
        self._data_cache.clear()
        if self._mode in (MODE_SURFACE, MODE_CUTS, MODE_CONTOUR):
            self._update_plot()

    def _on_cmap(self, _name: str) -> None:
        self._update_plot()

    def _on_alpha(self, val: int) -> None:
        self._alpha = val / 100.0
        self._alpha_label.setText(f'{val} %')
        self._update_plot()

    def _on_vexag(self, val: int) -> None:
        self._vert_exag = val
        self._vexag_label.setText(f'× {val}')
        self._update_plot()

    def _export_png(self) -> None:
        path, _ = QFileDialog.getSaveFileName(
            self, 'Save plot', f'{self.var_name}_3d.png', 'PNG (*.png)'
        )
        if path:
            self.fig.savefig(path, dpi=200, bbox_inches='tight',
                             facecolor=self.fig.get_facecolor())
            QMessageBox.information(self, 'Saved', f'Image saved:\n{path}')

    def _on_coast_toggle(self, on: bool) -> None:
        self._update_plot()

    def _on_var_changed(self, var_name: str) -> None:
        self.var_name = var_name
        self.setWindowTitle(f'3D View — {var_name}')
        self._data_cache.clear()
        try:
            self._load_nc()
            self._lev_slider.setRange(0, max(0, self.n_levs - 1))
            if self.level_idx >= self.n_levs:
                self.level_idx = max(0, self.n_levs - 1)
            self._lev_slider.setValue(self.level_idx)
            self._lev_slider.setEnabled(self.is_3d)
            if not self.is_3d and self._mode in (MODE_LEVELS, MODE_CUTS):
                self._mode_group.buttons()[0].setChecked(True)
                
            self._chk_wind.setEnabled(self._has_wind)
            self._chk_coast.setEnabled(getattr(self, 'landmask', None) is not None)
        except Exception:
            pass
        self._update_plot()

    def _on_autorotate_toggled(self, checked: bool) -> None:
        if checked:
            if not hasattr(self, '_rotate_timer'):
                from PyQt5.QtCore import QTimer
                self._rotate_timer = QTimer(self)
                self._rotate_timer.timeout.connect(self._do_rotate)
            self._rotate_timer.start(50)
        else:
            if hasattr(self, '_rotate_timer'):
                self._rotate_timer.stop()

    def _do_rotate(self):
        if hasattr(self, 'fig') and self.fig.axes and self._mode != MODE_CONTOUR:
            ax = self.fig.axes[0]
            if hasattr(ax, 'azim'):
                ax.azim = (ax.azim + 1) % 360
                self.canvas.draw_idle()

    def _on_fmin(self, val: int) -> None:
        self._filter_min = val / 100.0
        self._fmin_label.setText(f'{val} %')
        self._update_plot()
        
    def _on_fmax(self, val: int) -> None:
        self._filter_max = val / 100.0
        self._fmax_label.setText(f'{val} %')
        self._update_plot()
        
    def _on_zoom(self, val: int) -> None:
        self._zoom_factor = val / 100.0
        self._zoom_label.setText(f'{val} %')
        if hasattr(self, 'fig') and self.fig.axes and self._mode != MODE_CONTOUR:
            ax = self.fig.axes[0]
            if hasattr(ax, 'dist'):
                ax.dist = 10.0 / self._zoom_factor
            self.canvas.draw_idle()

    def _on_vector_changed(self, item) -> None:
        self._update_plot()
        
    def _export_python_script(self) -> None:
        path, _ = QFileDialog.getSaveFileName(self, 'Export Python Script', '', 'Python Files (*.py)')
        if not path:
            return
            
        py_code = f'''# GIS4WRF - Auto-generated Visualization Script
# You can run this in the QGIS Python Console or in a standalone Python environment.
import numpy as np
import netCDF4 as nc
import matplotlib.pyplot as plt
import matplotlib.cm as cm
import matplotlib.colors as mcolors

# Data Source
NC_FILE = r"{self.dataset_path}"
VAR_NAME = "{self.var_name}"
TIME_IDX = {self.time_idx}
LEVEL_IDX = {self.level_idx}

ds = nc.Dataset(NC_FILE)
var_data = ds.variables[VAR_NAME]
if var_data.ndim == 4:
    data_slice = var_data[TIME_IDX, LEVEL_IDX]
elif var_data.ndim == 3:
    data_slice = var_data[TIME_IDX]
else:
    data_slice = var_data[:]
    
data_slice = np.array(data_slice)

try:
    lats = np.array(ds.variables['XLAT'][0])
    lons = np.array(ds.variables['XLONG'][0])
except KeyError:
    ny, nx = data_slice.shape
    lons, lats = np.meshgrid(np.arange(nx), np.arange(ny))

# Matplotlib Figure
fig = plt.figure(figsize=(10, 6), facecolor="#1a1a2e")

# Plot Mode: {self._mode}
'''
        if self._mode == MODE_CONTOUR:
            py_code += f'''ax = fig.add_subplot(111)
ax.set_facecolor("#0d0d1a")
fig.patch.set_facecolor("#1a1a2e")
ax.tick_params(colors="#aaa")

# Contour Plot
cf = ax.contourf(lons, lats, data_slice, levels=20, cmap="{self._cmap_combo.currentText()}", alpha={self._alpha}, extend="both")
cs = ax.contour(lons, lats, data_slice, levels=10, colors="white", linewidths=0.4, alpha=0.6)
ax.clabel(cs, inline=True, fontsize=6, fmt="%.1f", colors="white")
cb = fig.colorbar(cf, ax=ax, pad=0.02, fraction=0.04)
cb.set_label(f"{{VAR_NAME}}", color="#ccc")
for lbl in cb.ax.get_yticklabels():
    lbl.set_color("#aaa")
'''
        else:
            py_code += f'''ax = fig.add_subplot(111, projection="3d")
ax.set_facecolor("#0d0d1a")
for pane in (ax.xaxis.pane, ax.yaxis.pane, ax.zaxis.pane):
    pane.fill = False
    pane.set_edgecolor("#333")
ax.tick_params(colors="#aaa")

try:
    terrain = np.array(ds.variables['HGT'][0])
except KeyError:
    terrain = np.zeros_like(data_slice)

# Surface Plot
norm = mcolors.Normalize(vmin=np.nanmin(data_slice), vmax=np.nanmax(data_slice))
cmap = cm.get_cmap("{self._cmap_combo.currentText()}")
colors = cmap(norm(data_slice))

ax.plot_surface(lons, lats, terrain * {self._vert_exag}, facecolors=colors, shade=True, alpha={self._alpha}, linewidth=0, antialiased=True)

# Formatting
ax.set_box_aspect((1, 1, 0.4))
sm = cm.ScalarMappable(cmap=cmap, norm=norm)
sm.set_array([])
cb = fig.colorbar(sm, ax=ax, shrink=0.55, pad=0.08)
cb.set_label(f"{{VAR_NAME}}", color="#ccc")
for lbl in cb.ax.get_yticklabels():
    lbl.set_color("#aaa")
'''
        
        py_code += '''
plt.show()
'''
        with open(path, 'w', encoding='utf-8') as f:
            f.write(py_code)
            
        QMessageBox.information(self, 'Export', f'Python script saved successfully to:\\n{path}\\n\\nYou can run it in the QGIS Python Console.')
